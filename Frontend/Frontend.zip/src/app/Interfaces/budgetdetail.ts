    export interface BudgetDetail {
        budgetdetailid : number,
        startamount:number,
        limitamount:number,
        manhour:number,
        containertype:string,
        containersize:number,
        budgetid : number,
        total_records :number
    }
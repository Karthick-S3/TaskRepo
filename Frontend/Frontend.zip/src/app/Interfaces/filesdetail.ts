export interface Filedetail {
    fid:number,
    originalname:string,
    storedname :string,
    filesize: number,
    uploaddate :Date,
    companyid:number,
    message: string,
    url: string;
}

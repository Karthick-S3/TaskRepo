export interface Currency {
    currencyid:number,
    currency:string
}
export interface Budget {
    budgetid : number,
    description:string,
    budgetcurrencyid:number,
    budgetactive:string,
    createdate:Date,
    companyid:number,
    total_records : number,
    currency : string
}
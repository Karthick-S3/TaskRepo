export interface State {
    sid:number,
    state :string,
    cid:number
}

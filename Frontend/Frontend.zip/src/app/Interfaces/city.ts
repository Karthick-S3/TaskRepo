export interface City {
    cityid:number,
    city:string,
    sid:number,
    cid:number
}

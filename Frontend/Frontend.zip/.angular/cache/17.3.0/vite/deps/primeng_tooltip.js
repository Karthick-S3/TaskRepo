import {
  Tooltip,
  TooltipModule
} from "./chunk-VISY2XMK.js";
import "./chunk-EK2YCWCT.js";
import "./chunk-AIUHVA56.js";
import "./chunk-MJOIYPDU.js";
import "./chunk-5RIGW3RL.js";
import "./chunk-J4B6MK7R.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map

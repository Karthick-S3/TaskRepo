import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-OLOMSAE2.js";
import "./chunk-63NGLDAQ.js";
import "./chunk-FHERTRZY.js";
import "./chunk-EK2YCWCT.js";
import "./chunk-AIUHVA56.js";
import "./chunk-MJOIYPDU.js";
import "./chunk-5RIGW3RL.js";
import "./chunk-J4B6MK7R.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
